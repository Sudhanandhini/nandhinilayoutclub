import React from 'react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-dark text-gray-300">
      <div className="bg-primary/10 border-t-4 border-gold">
        <div className="container-custom py-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 bg-primary flex items-center justify-center">
                <span className="text-gold font-serif font-bold text-lg">N</span>
              </div>
              <div>
                <div className="font-serif font-bold text-white text-lg leading-none">Nandini Layout</div>
                <div className="text-gold text-xs tracking-widest uppercase">Club</div>
              </div>
            </div>
            <p className="text-sm leading-relaxed mb-5 text-gray-400">
              The perfect place to enjoy life in a classy and friendly atmosphere. West Bangalore's premier social club since 1986.
            </p>
            <div className="flex gap-3">
              {[
                { label: 'FB', href: '#' },
                { label: 'TW', href: '#' },
                { label: 'YT', href: '#' },
                { label: 'IG', href: '#' },
              ].map(s => (
                <a key={s.label} href={s.href}
                  className="w-9 h-9 border border-gray-600 flex items-center justify-center text-xs font-bold hover:bg-gold hover:border-gold hover:text-white transition-all">
                  {s.label}
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-serif text-white text-lg font-bold mb-5 pb-2 border-b border-gold/40">Quick Links</h3>
            <ul className="space-y-2.5">
              {[
                ['Home', '/'], ['About Club', '/about'], ['Amenities', '/amenities'],
                ['Gallery', '/gallery'], ['Membership', '/membership'],
                ['News & Events', '/news-events'], ['Find Us', '/find-us'],
              ].map(([label, path]) => (
                <li key={path}>
                  <Link to={path} className="text-sm hover:text-gold transition-colors flex items-center gap-2">
                    <span className="text-gold text-xs">›</span> {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Facilities */}
          <div>
            <h3 className="font-serif text-white text-lg font-bold mb-5 pb-2 border-b border-gold/40">Facilities</h3>
            <ul className="space-y-2.5">
              {[
                'Sports Facilities', 'Health & Wellness', 'Guest Rooms',
                'Conferences & Banquets', 'Food & Beverage', 'Events & Activities',
              ].map(f => (
                <li key={f}>
                  <Link to="/amenities" className="text-sm hover:text-gold transition-colors flex items-center gap-2">
                    <span className="text-gold text-xs">›</span> {f}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-serif text-white text-lg font-bold mb-5 pb-2 border-b border-gold/40">Contact Us</h3>
            <div className="space-y-4 text-sm">
              <div className="flex gap-3">
                <span className="text-gold mt-0.5">📍</span>
                <p className="text-gray-400">Nandini Layout, Chord Road,<br />West Bangalore - 560 086<br />Karnataka, India</p>
              </div>
              <div className="flex gap-3">
                <span className="text-gold">📞</span>
                <div className="text-gray-400">
                  <a href="tel:+918023456789" className="hover:text-gold transition-colors block">+91 80 2345 6789</a>
                  <a href="tel:+919876543210" className="hover:text-gold transition-colors block">+91 98765 43210</a>
                </div>
              </div>
              <div className="flex gap-3">
                <span className="text-gold">✉</span>
                <a href="mailto:info@nandinilayoutclub.in" className="text-gray-400 hover:text-gold transition-colors">
                  info@nandinilayoutclub.in
                </a>
              </div>
              <div className="flex gap-3">
                <span className="text-gold">🕒</span>
                <div className="text-gray-400 text-xs">
                  <p>Mon – Fri: 6:00 AM – 11:00 PM</p>
                  <p>Sat – Sun: 6:00 AM – 11:30 PM</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-gray-800 py-5">
        <div className="container-custom flex flex-col md:flex-row justify-between items-center gap-3 text-xs text-gray-500">
          <p>© {new Date().getFullYear()} Nandini Layout Club. All Rights Reserved.</p>
          <div className="flex gap-5">
            <Link to="/privacy" className="hover:text-gold">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-gold">Terms of Use</Link>
            <Link to="/sitemap" className="hover:text-gold">Sitemap</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
