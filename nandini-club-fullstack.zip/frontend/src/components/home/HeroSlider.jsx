import React, { useEffect, useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Navigation, Pagination, EffectFade } from 'swiper/modules';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import API, { getImageUrl } from '../../services/api';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/effect-fade';

const defaultSlides = [
  {
    id: 1,
    title: 'Welcome To Nandini Layout Club',
    subtitle: 'In Pursuit of Excellence',
    image_url: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=1600&q=80',
  },
  {
    id: 2,
    title: 'Experience Luxury & Leisure',
    subtitle: "West Bangalore's Premier Club Since 1986",
    image_url: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=1600&q=80',
  },
  {
    id: 3,
    title: 'World Class Amenities',
    subtitle: 'Sports, Leisure & Hospitality Under One Roof',
    image_url: 'https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=1600&q=80',
  },
];

export default function HeroSlider() {
  const [slides, setSlides] = useState(defaultSlides);

  useEffect(() => {
    API.get('/banners')
      .then(res => { if (res.data.data?.length) setSlides(res.data.data); })
      .catch(() => {});
  }, []);

  return (
    <div className="relative w-full h-screen min-h-[500px]">
      <Swiper
        modules={[Autoplay, Navigation, Pagination, EffectFade]}
        effect="fade"
        autoplay={{ delay: 5000, disableOnInteraction: false }}
        navigation
        pagination={{ clickable: true }}
        loop
        className="w-full h-full">
        {slides.map(slide => (
          <SwiperSlide key={slide.id}>
            <div className="relative w-full h-full">
              <img
                src={getImageUrl(slide.image_url)}
                alt={slide.title || 'Club banner'}
                className="w-full h-screen object-cover"
                loading={slide.id === 1 ? 'eager' : 'lazy'}
              />
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/60" />
              {/* Content */}
              {(slide.title || slide.subtitle) && (
                <div className="absolute inset-0 flex items-center justify-center text-center">
                  <div className="max-w-3xl px-6">
                    {slide.subtitle && (
                      <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="text-gold uppercase tracking-[0.3em] text-sm font-sans font-semibold mb-4">
                        {slide.subtitle}
                      </motion.p>
                    )}
                    <motion.h1
                      initial={{ opacity: 0, y: 30 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4 }}
                      className="font-serif text-4xl md:text-6xl text-white font-bold leading-tight mb-6">
                      {slide.title}
                    </motion.h1>
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.7 }}
                      className="flex flex-col sm:flex-row gap-4 justify-center">
                      <Link to="/about" className="btn-gold">Explore Club</Link>
                      <Link to="/membership/apply" className="btn-outline border-white text-white hover:bg-white hover:text-primary">
                        Join Membership
                      </Link>
                    </motion.div>
                  </div>
                </div>
              )}
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
      {/* Scroll down indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center text-white/70 gap-2"
        animate={{ y: [0, 8, 0] }}
        transition={{ repeat: Infinity, duration: 1.8 }}>
        <span className="text-xs uppercase tracking-widest font-sans">Scroll</span>
        <div className="w-px h-10 bg-white/40"></div>
      </motion.div>
    </div>
  );
}
