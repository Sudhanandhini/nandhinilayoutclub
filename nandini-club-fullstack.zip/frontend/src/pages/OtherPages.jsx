import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import MainLayout from '../layouts/MainLayout';
import { PageHero, Breadcrumbs, LoadingSpinner } from '../components/common/UI';
import API from '../services/api';

export function FindUsPage() {
  return (
    <MainLayout>
      <Helmet>
        <title>Find Us | Nandini Layout Club</title>
        <meta name="description" content="Find Nandini Layout Club location in West Bangalore." />
      </Helmet>
      <div className="pt-20">
        <PageHero title="Find Us" subtitle="Location & Directions" />
        <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'Find Us' }]} />
        <section className="py-16">
          <div className="container-custom">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
              <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                <p className="section-subtitle">How to Reach Us</p>
                <h2 className="section-title mb-4">Our Location</h2>
                <div className="section-divider"></div>
                <div className="space-y-5 mt-6">
                  <div className="flex gap-4">
                    <span className="text-2xl">📍</span>
                    <div>
                      <p className="font-semibold text-primary mb-1">Address</p>
                      <p className="text-gray-600 text-sm">Nandini Layout, Chord Road,<br/>West Bangalore - 560 086,<br/>Karnataka, India</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <span className="text-2xl">🚌</span>
                    <div>
                      <p className="font-semibold text-primary mb-1">By Bus</p>
                      <p className="text-gray-600 text-sm">BMTC buses on Chord Road route. Stop: Nandini Layout</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <span className="text-2xl">🚇</span>
                    <div>
                      <p className="font-semibold text-primary mb-1">By Metro</p>
                      <p className="text-gray-600 text-sm">Nearest: Rajajinagar Metro Station (2 km)</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <span className="text-2xl">🚗</span>
                    <div>
                      <p className="font-semibold text-primary mb-1">By Car</p>
                      <p className="text-gray-600 text-sm">Ample parking available. From Rajajinagar: take Chord Road, turn at Nandini Layout signal.</p>
                    </div>
                  </div>
                </div>
              </motion.div>
              {/* Map embed */}
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="h-80 md:h-96 bg-gray-200">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.4234!2d77.5295!3d12.9912!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTLCsDU5JzI4LjMiTiA3N8KwMzEnNDYuMiJF!5e0!3m2!1sen!2sin!4v1620000000000!5m2!1sen!2sin"
                  width="100%" height="100%" style={{ border: 0 }} allowFullScreen loading="lazy"
                  title="Nandini Layout Club Location" />
              </motion.div>
            </div>
          </div>
        </section>
      </div>
    </MainLayout>
  );
}

export function NewsEventsPage() {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);

  const defaultNews = [
    { id: 1, title: 'Annual General Meeting 2024', content: 'The AGM will be held on the last Sunday of March. All members are requested to attend.', event_date: '2024-03-31', is_featured: true },
    { id: 2, title: 'Holi Celebration 2024', content: 'Join us for a grand Holi celebration. Special cultural programs, music, and festive delicacies await you.', event_date: '2024-03-25', is_featured: true },
    { id: 3, title: 'New Year\'s Eve Gala', content: 'Ring in the New Year with a spectacular gala dinner and live music.', event_date: '2024-12-31', is_featured: false },
  ];

  useEffect(() => {
    API.get('/news')
      .then(res => setNews(res.data.data?.length ? res.data.data : defaultNews))
      .catch(() => setNews(defaultNews))
      .finally(() => setLoading(false));
  }, []);

  return (
    <MainLayout>
      <Helmet>
        <title>News & Events | Nandini Layout Club</title>
      </Helmet>
      <div className="pt-20">
        <PageHero title="News & Events" subtitle="Stay Updated" />
        <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'News & Events' }]} />
        <section className="py-16">
          <div className="container-custom">
            {loading ? <LoadingSpinner /> : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {news.map((item, i) => (
                  <motion.div key={item.id}
                    initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                    className="card overflow-hidden">
                    <div className="h-40 bg-gradient-to-br from-primary to-primary-700 flex items-center justify-center">
                      <span className="font-serif text-white text-6xl opacity-20">N</span>
                    </div>
                    <div className="p-6">
                      {item.is_featured && (
                        <span className="text-xs bg-gold text-white px-2 py-0.5 font-sans uppercase tracking-wider mb-3 inline-block">Featured</span>
                      )}
                      <h3 className="font-serif text-lg text-primary font-bold mb-2">{item.title}</h3>
                      {item.event_date && (
                        <p className="text-gold text-xs font-sans mb-3">
                          📅 {new Date(item.event_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
                        </p>
                      )}
                      <p className="text-gray-600 text-sm leading-relaxed line-clamp-3">{item.content?.replace(/<[^>]*>/g, '')}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </section>
      </div>
    </MainLayout>
  );
}

export function RoomsPage() {
  const rooms = [
    { type: 'Standard Room', price: 'Contact Club', features: ['AC Room', 'Twin/Double Bed', 'Attached Bath', 'TV', 'Wi-Fi'] },
    { type: 'Deluxe Room', price: 'Contact Club', features: ['AC Room', 'King Bed', 'Attached Bath with Tub', 'TV', 'Wi-Fi', 'Minibar'] },
    { type: 'Suite', price: 'Contact Club', features: ['AC Suite', 'King Bed', 'Living Area', 'Jacuzzi', 'TV', 'Wi-Fi', 'Complimentary Breakfast'] },
  ];
  return (
    <MainLayout>
      <Helmet><title>Rooms & Accommodation | Nandini Layout Club</title></Helmet>
      <div className="pt-20">
        <PageHero title="Guest Rooms" subtitle="Comfortable Stays" />
        <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'Rooms' }]} />
        <section className="py-16">
          <div className="container-custom">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {rooms.map((room, i) => (
                <motion.div key={room.type}
                  initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                  className="bg-white border border-gray-200 p-8 hover:shadow-xl transition-shadow">
                  <h3 className="font-serif text-xl text-primary font-bold mb-2">{room.type}</h3>
                  <p className="text-gold font-sans font-semibold text-sm mb-5">{room.price}</p>
                  <ul className="space-y-2 mb-6">
                    {room.features.map(f => <li key={f} className="flex gap-2 text-sm text-gray-600"><span className="text-gold">✓</span>{f}</li>)}
                  </ul>
                  <a href="/find-us" className="btn-primary block text-center text-xs">Book / Enquire</a>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </MainLayout>
  );
}
