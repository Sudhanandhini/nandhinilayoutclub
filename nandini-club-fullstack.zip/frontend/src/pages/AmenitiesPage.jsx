import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import MainLayout from '../layouts/MainLayout';
import { PageHero, Breadcrumbs, LoadingSpinner } from '../components/common/UI';
import API, { getImageUrl } from '../services/api';

const defaultFacilities = [
  { id: 1, name: 'Sports Facilities', description: 'Badminton (wooden shuttle court), Table Tennis, Chess, Carrom. State-of-the-art equipment maintained regularly for your enjoyment.', category: 'Sports', image_url: 'https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=500&q=70' },
  { id: 2, name: 'Health & Wellness', description: 'Fully equipped gymnasium with modern machines, personal trainers, and dedicated wellness programs for all fitness levels.', category: 'Wellness', image_url: 'https://images.unsplash.com/photo-1544124950-a0de5a98e25e?w=500&q=70' },
  { id: 3, name: 'Guest Rooms', description: 'Comfortable, air-conditioned guest rooms for members and their guests. Clean, well-maintained with all modern amenities.', category: 'Accommodation', image_url: 'https://images.unsplash.com/photo-1571624436279-b272aff752b5?w=500&q=70' },
  { id: 4, name: 'Conferences & Banquets', description: 'Modern conference halls and banquet facilities for corporate events, weddings, receptions, and private celebrations.', category: 'Events', image_url: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=500&q=70' },
  { id: 5, name: 'Food & Beverage', description: 'Multi-cuisine restaurant and bar serving breakfast, lunch, dinner and snacks. From South Indian delicacies to continental cuisine.', category: 'Dining', image_url: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=500&q=70' },
  { id: 6, name: 'Events & Activities', description: 'Year-round cultural events, festivals, tournaments, and social gatherings. Something for every member and their families.', category: 'Events', image_url: 'https://images.unsplash.com/photo-1513623935135-c896b59073c1?w=500&q=70' },
];

export default function AmenitiesPage() {
  const [facilities, setFacilities] = useState(defaultFacilities);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    API.get('/facilities')
      .then(res => { if (res.data.data?.length) setFacilities(res.data.data); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <MainLayout>
      <Helmet>
        <title>Amenities & Facilities | Nandini Layout Club</title>
        <meta name="description" content="Explore world-class amenities at Nandini Layout Club - sports, dining, wellness, accommodation and more." />
      </Helmet>
      <div className="pt-20">
        <PageHero title="Amenities & Facilities" subtitle="World-Class Offerings" />
        <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'Amenities' }]} />

        <section className="py-16">
          <div className="container-custom">
            <div className="text-center mb-12">
              <p className="section-subtitle">What We Offer</p>
              <h2 className="section-title">Club Facilities</h2>
              <div className="section-divider mx-auto"></div>
              <p className="text-gray-600 max-w-2xl mx-auto mt-4">
                Nandini Layout Club offers an unparalleled range of facilities spread across multiple floors, 
                catering to every aspect of leisure, sport, health and social engagement.
              </p>
            </div>

            {loading ? <LoadingSpinner /> : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {facilities.map((fac, i) => (
                  <motion.div key={fac.id}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className="card group overflow-hidden">
                    <div className="h-52 overflow-hidden">
                      <img src={getImageUrl(fac.image_url)}
                        alt={fac.name}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                        loading="lazy" />
                    </div>
                    <div className="p-6">
                      <span className="text-xs text-gold uppercase tracking-widest font-sans font-semibold">{fac.category}</span>
                      <h3 className="font-serif text-xl text-primary font-bold mt-1 mb-3">{fac.name}</h3>
                      <p className="text-gray-600 text-sm leading-relaxed">{fac.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}

            {/* Basement / Floor breakdown */}
            <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { floor: 'Basement', items: ['Wooden Shuttle Court (Badminton)', 'Table Tennis', 'Chess & Carrom', 'Billiards Lounge (Planned)'] },
                { floor: 'Ground Floor', items: ['Front Office & Reception', 'Multi-purpose Hall', 'Members Lounge', 'Parking Area'] },
                { floor: 'Upper Floors', items: ['Multi-cuisine Restaurant', 'Guest Rooms', 'Conference Halls', 'Terrace Garden'] },
              ].map((f, i) => (
                <motion.div key={f.floor}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-cream p-7 border-l-4 border-primary">
                  <h3 className="font-serif text-xl text-primary font-bold mb-4">{f.floor}</h3>
                  <ul className="space-y-2">
                    {f.items.map(item => (
                      <li key={item} className="flex gap-2 text-sm text-gray-600">
                        <span className="text-gold mt-0.5">✓</span> {item}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </MainLayout>
  );
}
