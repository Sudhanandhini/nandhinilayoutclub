import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { useParams } from 'react-router-dom';
import MainLayout from '../layouts/MainLayout';
import { PageHero, Breadcrumbs } from '../components/common/UI';
import API from '../services/api';
import toast from 'react-hot-toast';

const membershipTypes = [
  { value: 'individual', label: 'Individual', price: 'Contact Club', benefits: ['Access to all club facilities', 'Voting rights', 'Member discounts', 'Guest passes (2/month)'] },
  { value: 'family', label: 'Family', price: 'Contact Club', benefits: ['All Individual benefits', 'Spouse & children included', 'Family events access', 'Additional guest passes'] },
  { value: 'corporate', label: 'Corporate', price: 'Contact Club', benefits: ['Multiple member cards', 'Conference room priority', 'Corporate event facilities', 'Dedicated relationship manager'] },
  { value: 'senior', label: 'Senior Citizen', price: 'Contact Club', benefits: ['Special discounted rates', 'Senior-friendly facilities', 'Health programs access', 'Priority service'] },
];

export default function MembershipPage() {
  const { subpage } = useParams();
  const isApply = subpage === 'apply';

  if (isApply) return <MembershipApplyForm />;
  if (subpage === 'managing-committee') return <ManagingCommittee />;
  if (subpage === 'sub-committees') return <SubCommittees />;

  return (
    <MainLayout>
      <Helmet>
        <title>Membership | Nandini Layout Club</title>
        <meta name="description" content="Join Nandini Layout Club - explore membership plans and benefits." />
      </Helmet>
      <div className="pt-20">
        <PageHero title="Membership" subtitle="Join Our Community" />
        <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'Membership' }]} />
        <section className="py-16">
          <div className="container-custom">
            <div className="text-center mb-12">
              <p className="section-subtitle">Exclusive Plans</p>
              <h2 className="section-title">Membership Categories</h2>
              <div className="section-divider mx-auto"></div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {membershipTypes.map((type, i) => (
                <motion.div key={type.value}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-white border border-gray-200 p-7 hover:border-primary hover:shadow-xl transition-all group">
                  <h3 className="font-serif text-xl text-primary font-bold mb-1">{type.label}</h3>
                  <p className="text-gold text-sm font-sans font-semibold mb-5">{type.price}</p>
                  <ul className="space-y-2.5 mb-7">
                    {type.benefits.map(b => (
                      <li key={b} className="flex gap-2 text-sm text-gray-600">
                        <span className="text-gold flex-shrink-0 mt-0.5">✓</span> {b}
                      </li>
                    ))}
                  </ul>
                  <a href="/membership/apply"
                    className="block text-center btn-primary text-xs w-full">Apply Now</a>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </MainLayout>
  );
}

function MembershipApplyForm() {
  const [form, setForm] = useState({ full_name: '', email: '', phone: '', address: '', membership_type: 'individual', message: '' });
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = e => setForm(p => ({ ...p, [e.target.name]: e.target.value }));

  const handleSubmit = async e => {
    e.preventDefault();
    if (!form.full_name || !form.email || !form.phone) {
      toast.error('Please fill all required fields.'); return;
    }
    setLoading(true);
    try {
      await API.post('/membership/apply', form);
      setSubmitted(true);
      toast.success('Application submitted successfully!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <MainLayout>
      <Helmet><title>Apply for Membership | Nandini Layout Club</title></Helmet>
      <div className="pt-20">
        <PageHero title="Apply for Membership" subtitle="Join Our Family" />
        <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'Membership', href: '/membership' }, { label: 'Apply' }]} />
        <section className="py-16">
          <div className="container-custom max-w-2xl mx-auto">
            {submitted ? (
              <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
                className="text-center py-16">
                <div className="text-6xl mb-4">✅</div>
                <h2 className="font-serif text-2xl text-primary font-bold mb-3">Application Submitted!</h2>
                <p className="text-gray-600">Thank you for your interest. Our team will contact you within 3–5 business days.</p>
              </motion.div>
            ) : (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                className="bg-white p-8 shadow-lg border-t-4 border-primary">
                <h3 className="font-serif text-xl text-primary font-bold mb-6">Membership Application Form</h3>
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Full Name *</label>
                      <input name="full_name" value={form.full_name} onChange={handleChange} required className="input-field" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Email *</label>
                      <input type="email" name="email" value={form.email} onChange={handleChange} required className="input-field" />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Phone *</label>
                      <input name="phone" value={form.phone} onChange={handleChange} required className="input-field" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Membership Type</label>
                      <select name="membership_type" value={form.membership_type} onChange={handleChange} className="input-field">
                        {membershipTypes.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Address</label>
                    <textarea name="address" value={form.address} onChange={handleChange} rows={3} className="input-field resize-none" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Additional Message</label>
                    <textarea name="message" value={form.message} onChange={handleChange} rows={3} className="input-field resize-none" />
                  </div>
                  <button type="submit" disabled={loading} className="btn-primary w-full disabled:opacity-50">
                    {loading ? 'Submitting...' : 'Submit Application'}
                  </button>
                </form>
              </motion.div>
            )}
          </div>
        </section>
      </div>
    </MainLayout>
  );
}

function ManagingCommittee() {
  const committee = [
    { name: 'Mr. K. Raghavendra', role: 'President' },
    { name: 'Mr. Suresh Kumar', role: 'Vice President' },
    { name: 'Mr. Anil Sharma', role: 'Hon. Secretary' },
    { name: 'Mr. P. Venkatesh', role: 'Treasurer' },
    { name: 'Mr. Ravi Nair', role: 'Joint Secretary' },
    { name: 'Mr. Mohan Das', role: 'Committee Member' },
    { name: 'Mrs. Sudha Rao', role: 'Committee Member' },
    { name: 'Mr. Girish B.', role: 'Committee Member' },
  ];
  return (
    <MainLayout>
      <Helmet><title>Managing Committee | Nandini Layout Club</title></Helmet>
      <div className="pt-20">
        <PageHero title="Managing Committee" subtitle="Club Leadership" />
        <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'Membership', href: '/membership' }, { label: 'Managing Committee' }]} />
        <section className="py-16">
          <div className="container-custom">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {committee.map((m, i) => (
                <motion.div key={m.name}
                  initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                  className="bg-white p-6 text-center shadow-sm hover:shadow-md transition-shadow border-t-4 border-primary">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="font-serif text-2xl text-primary font-bold">{m.name[0]}</span>
                  </div>
                  <h3 className="font-serif font-bold text-primary">{m.name}</h3>
                  <p className="text-gold text-xs font-sans tracking-wide mt-1">{m.role}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </MainLayout>
  );
}

function SubCommittees() {
  const subs = [
    { name: 'Sports Committee', members: ['Mr. Ashok Kumar', 'Mr. Rajesh N.', 'Mrs. Priya S.'] },
    { name: 'Cultural Committee', members: ['Mrs. Kavitha R.', 'Mr. Santosh B.', 'Miss. Deepa K.'] },
    { name: 'Finance Committee', members: ['Mr. Ramesh P.', 'Mr. Sunil J.', 'Mr. Anand V.'] },
    { name: 'Food & Beverage Committee', members: ['Mrs. Sunita D.', 'Mr. Prasad M.', 'Mr. Kumar N.'] },
  ];
  return (
    <MainLayout>
      <Helmet><title>Sub Committees | Nandini Layout Club</title></Helmet>
      <div className="pt-20">
        <PageHero title="Sub Committees" subtitle="Club Organization" />
        <Breadcrumbs items={[{ label: 'Home', href: '/' }, { label: 'Membership', href: '/membership' }, { label: 'Sub Committees' }]} />
        <section className="py-16">
          <div className="container-custom">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {subs.map((s, i) => (
                <motion.div key={s.name}
                  initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                  className="bg-cream p-7 border-l-4 border-primary">
                  <h3 className="font-serif text-xl text-primary font-bold mb-4">{s.name}</h3>
                  <ul className="space-y-2">
                    {s.members.map(m => <li key={m} className="text-gray-600 text-sm flex gap-2"><span className="text-gold">›</span> {m}</li>)}
                  </ul>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </MainLayout>
  );
}
