# Nandini Layout Club — Full Stack Web Application

A modern React + Node.js rebuild of [nandinilayoutclub.in](https://www.nandinilayoutclub.in) — West Bangalore's premier social club website.

---

## Project Overview

| Layer | Stack |
|-------|-------|
| Frontend | React 18 + Vite, Tailwind CSS, Framer Motion, Swiper.js |
| Backend | Node.js + Express, MySQL, JWT Auth |
| Database | MySQL 8.0 |
| Email | Nodemailer (Gmail SMTP) |
| Uploads | Multer |

---

## Folder Structure

```
nandini-club/
├── frontend/          # React + Vite application
│   ├── src/
│   │   ├── admin/     # Admin panel pages
│   │   ├── components/
│   │   ├── context/
│   │   ├── layouts/
│   │   ├── pages/
│   │   └── services/
│   ├── README.md
│   └── package.json
│
├── backend/           # Node.js + Express API
│   ├── config/
│   ├── controllers/
│   ├── middlewares/
│   ├── routes/
│   ├── uploads/       # Generated at runtime
│   ├── schema.sql     # Database schema + seed data
│   ├── server.js
│   ├── README.md
│   └── package.json
│
└── README.md          # This file
```

---

## Quick Start

### 1. Database

```bash
mysql -u root -p < backend/schema.sql
```

### 2. Backend

```bash
cd backend
cp .env.example .env     # Edit with your DB credentials
npm install
npm run dev              # http://localhost:5000
```

### 3. Frontend

```bash
cd frontend
cp .env.example .env     # Edit if needed
npm install
npm run dev              # http://localhost:5173
```

---

## Features

### Public Website
- ✅ Hero slider with autoplay (Swiper.js)
- ✅ Facilities icon grid
- ✅ About section with 3-column layout
- ✅ Stats bar (35+ years, 1000+ members...)
- ✅ Membership CTA section
- ✅ Testimonials carousel
- ✅ Contact form with email notification
- ✅ WhatsApp floating button
- ✅ Sticky responsive navbar with dropdowns
- ✅ Mobile hamburger menu
- ✅ SEO meta tags (React Helmet Async)
- ✅ Smooth page transitions (Framer Motion)
- ✅ Breadcrumbs on all inner pages
- ✅ Lazy loaded images

### Gallery
- ✅ Filterable by category
- ✅ Lightbox preview with close button
- ✅ Animated grid with Framer Motion layout

### Membership
- ✅ Membership plans display
- ✅ Application form
- ✅ Email confirmation to applicant + admin
- ✅ Managing Committee page
- ✅ Sub Committees page

### Admin Panel
- ✅ JWT-secured login
- ✅ Dashboard with stats
- ✅ Hero Banner management (upload, toggle, delete)
- ✅ Gallery management (upload, categorize, delete)
- ✅ Facilities management (CRUD + image upload)
- ✅ Testimonials management (CRUD)
- ✅ Pages content editor (HTML)
- ✅ News & Events management
- ✅ Contact inquiries with status tracking
- ✅ Membership applications with approval workflow

---

## Environment Variables

### Backend (`backend/.env`)
```
PORT=5000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_db_password
DB_NAME=nandini_club
JWT_SECRET=your_jwt_secret
SMTP_USER=your@gmail.com
SMTP_PASS=your_app_password
MAIL_TO=admin@nandinilayoutclub.in
FRONTEND_URL=http://localhost:5173
```

### Frontend (`frontend/.env`)
```
VITE_API_URL=http://localhost:5000/api
VITE_UPLOADS_URL=http://localhost:5000
VITE_WHATSAPP_NUMBER=919876543210
```

---

## Admin Credentials (Default)

| Field | Value |
|-------|-------|
| URL | `/admin/login` |
| Email | `admin@nandinilayoutclub.in` |
| Password | `password` |

> ⚠️ Change the admin password immediately after first login!

---

## Deployment

### cPanel
1. **Backend**: Setup Node.js App → point to `/backend`, startup file `server.js`
2. **Frontend**: `npm run build` → upload `/dist` to `public_html`
3. Add `.htaccess` to `/dist` for React Router support
4. Import `schema.sql` via phpMyAdmin

### VPS (Ubuntu + Nginx + PM2)
See individual READMEs in `/frontend` and `/backend` for full Nginx configs.

---

## Color Palette

| Name | Hex |
|------|-----|
| Primary (Deep Red) | `#8B1A1A` |
| Gold | `#C8972A` |
| Dark | `#1a1a1a` |
| Cream | `#FAF7F0` |

## Fonts
- **Headings**: Playfair Display
- **Body**: Source Sans 3

---

Built with ❤️ to replicate Nandini Layout Club's existing WordPress site as a modern full-stack application.
